# IN-ARCP manuscript, Overleaf container (R22)

Upload as **New Project -> Upload Project**. Then **Menu**: Compiler **pdfLaTeX**, Main
document **main.tex**, TeX Live newest. **Recompile** gives **11 pages**.

- Every result number is a macro in `generated/*.tex`, produced from saved outcomes by the
  scripts in `analysis_provenance/` of the project repository. Never type a result into
  `main.tex`; change it at its source and regenerate.
- The paper is 11 pages by decision, not by accident: T-RS charges US$200 for each page past
  ten, and page 11 was bought in R18 for the operating-regime passage, the cost design rule
  and larger Figures 2 and 3. Do not let it reach 12.
- Figures 2 and 3 are drawn at their final print size with readable labels. Figure 3
  combines the preserved onset panel with the measured 48-look guarded trajectories.
  Its provenance and source are in `research/r7c/r22/make_guard_figures.py`.
- `IEEEtran.cls` (V1.8b) and `IEEEtran.bst` (1.14) are pinned copies of the official IEEE
  files. Leave them in place.
- Fig. 1 is TikZ inside `main.tex`; Overleaf's TeX Live has what it needs.
- When you are done, **Menu -> Download -> Source** and put `main.tex` back in
  `manuscript/` of the package. That folder is the single live copy.
