# IN-ARCP supplementary material, Overleaf container (R22)

Upload as a **separate** project. Main document **supplement.tex**. The page count is checked by this build script.

The supplement reads the paper's equation, appendix and proposition numbers from
`manuscript_main.aux`, which is included here. If you renumber anything in the manuscript:

1. recompile the manuscript project;
2. download its `main.aux` from **Logs and output files**;
3. upload it here as `manuscript_main.aux`.

The compact supplement contains the supporting proofs and readable result tables.
Its full-output index points to the frozen repository; original terminal dumps are
not required to typeset this PDF. The local package documents table provenance and
the compact-source generator. Preserve the uncertainty intervals and disclosures.
