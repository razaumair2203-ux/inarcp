IN-ARCP — IEEE Access — 2026-09-28_R4

Upload this ZIP using Overleaf > New Project > Upload Project.
Select main.tex as Main document and pdfLaTeX as Compiler, then Recompile.
Expected: 12 manuscript pages; Algorithm 1 p.3, UML Figure 1 p.4, Algorithm 2 p.6.
Select supplement.tex to compile the 8-page supplementary document.

The official IEEE Access class and its fonts are included unchanged, verified
against the ZIP downloaded from IEEE's website on 28 September 2026.
See template_provenance.json for the official source and every dependency hash.

Edit main.tex for the article, algorithm_inarcp.tex / algorithm_split.tex for
the pseudocode, and sequence_diagram.tex for the UML. latexmkrc rebuilds the
diagram as a vector PDF automatically before compiling the article.

The compiled/ folder contains reference PDFs under distinct revision names.
Those are not the output of your new Overleaf build; download that from its PDF
viewer. No main.pdf is bundled, avoiding a stale output with the same filename.

Repository source: https://github.com/razaumair2203-ux/inarcp
Branch: main. Research revision integrated with author approval through PR #1.
main.tex is byte-identical to paper/manuscript.tex at package creation.
This archive is an importable project, not an existing hosted Overleaf project.

Template/font rights and notices remain with their respective owners. The
repository MIT software license does not relicense those files or the paper.
No journal submission or acceptance is represented by this research draft.
