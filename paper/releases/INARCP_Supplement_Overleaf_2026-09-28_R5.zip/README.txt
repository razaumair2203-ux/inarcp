IN-ARCP R5 Supplement - standalone Overleaf project
Upload this ZIP as a new Overleaf project.
Main document: main.tex
Compiler: pdfLaTeX
Compile twice to resolve references.
